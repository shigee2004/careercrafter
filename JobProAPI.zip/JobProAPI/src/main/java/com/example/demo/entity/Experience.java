package com.example.demo.entity;

import jakarta.persistence.Embeddable;

@Embeddable
public class Experience {
	private Long id; 
	private String title;
    private String company;
    private String fromDate;
    private String toDate;
    private String description;

    public Experience() {}

    public Experience(String title, String company, String fromDate, String toDate, String description) {
        this.title = title;
        this.company = company;
        this.fromDate = fromDate;
        this.toDate = toDate;
        this.description = description;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getTitle() { 
    	return title; 
    }
    public void setTitle(String title) { 
    	this.title = title; 
    }

    public String getCompany() { 
    	return company; 
    }
    
    public void setCompany(String company) { 
    	this.company = company; 
    }

    public String getFromDate() { 
    	return fromDate; 
    }
    
    public void setFromDate(String fromDate) { 
    	this.fromDate = fromDate; 
    }

    public String getToDate() { 
    	return toDate; 
    }
    public void setToDate(String toDate) { 
    	this.toDate = toDate; 
    }

    public String getDescription() { 
    	return description; 
    }
    public void setDescription(String description) { 
    	this.description = description; 
    }

}
