package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Application;

public interface ApplicationService {
	List<Application> getAllApplications();
    Application getApplicationById(String id);
    Application saveApplication(Application application);
    void deleteApplication(String id);

}
