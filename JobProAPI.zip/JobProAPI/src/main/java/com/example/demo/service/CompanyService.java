package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Company;

public interface CompanyService {
	List<Company> getAllCompanies();
    Company getCompanyById(String id);
    Company saveCompany(Company company); // Works for Create & Update
    void deleteCompany(String id);

}
