package com.example.demo.entity;

import java.util.List;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Profile {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String fullName;
    private String email;
    private String phone;
    private String dob;
    private String userId;

    // Education (flattened)
    private String tenthSchool;
    private String tenthYear;
    private String tenthMarks;

    private String twelfthSchool;
    private String twelfthYear;
    private String twelfthMarks;

    private String collegeName;
    private String collegeYear;
    private String collegeMarks;

    // Skills
    @ElementCollection
    private List<String> skills;

    // Certifications
    @ElementCollection
    private List<String> certifications;

    // Internships (simple list — just store company, role etc. as a string or JSON if you want)
    @ElementCollection
    private List<String> internships;

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getDob() { return dob; }
    public void setDob(String dob) { this.dob = dob; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getTenthSchool() { return tenthSchool; }
    public void setTenthSchool(String tenthSchool) { this.tenthSchool = tenthSchool; }

    public String getTenthYear() { return tenthYear; }
    public void setTenthYear(String tenthYear) { this.tenthYear = tenthYear; }

    public String getTenthMarks() { return tenthMarks; }
    public void setTenthMarks(String tenthMarks) { this.tenthMarks = tenthMarks; }

    public String getTwelfthSchool() { return twelfthSchool; }
    public void setTwelfthSchool(String twelfthSchool) { this.twelfthSchool = twelfthSchool; }

    public String getTwelfthYear() { return twelfthYear; }
    public void setTwelfthYear(String twelfthYear) { this.twelfthYear = twelfthYear; }

    public String getTwelfthMarks() { return twelfthMarks; }
    public void setTwelfthMarks(String twelfthMarks) { this.twelfthMarks = twelfthMarks; }

    public String getCollegeName() { return collegeName; }
    public void setCollegeName(String collegeName) { this.collegeName = collegeName; }

    public String getCollegeYear() { return collegeYear; }
    public void setCollegeYear(String collegeYear) { this.collegeYear = collegeYear; }

    public String getCollegeMarks() { return collegeMarks; }
    public void setCollegeMarks(String collegeMarks) { this.collegeMarks = collegeMarks; }

    public List<String> getSkills() { return skills; }
    public void setSkills(List<String> skills) { this.skills = skills; }

    public List<String> getCertifications() { return certifications; }
    public void setCertifications(List<String> certifications) { this.certifications = certifications; }

    public List<String> getInternships() { return internships; }
    public void setInternships(List<String> internships) { this.internships = internships; }
}
