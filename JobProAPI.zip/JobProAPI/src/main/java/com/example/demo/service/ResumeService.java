package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Resume;

public interface ResumeService {
	List<Resume> getAllResumes();
    Resume getResumeById(String id);
    Resume saveResume(Resume resume);
    void deleteResume(String id);

}
