package com.example.demo.controller;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Resume;
import com.example.demo.service.ResumeService;

@RestController
@RequestMapping("/resumes")
@CrossOrigin(origins = "http://localhost:3000") // React app

public class ResumeController {
	private final ResumeService resumeService;

    public ResumeController(ResumeService resumeService) {
        this.resumeService = resumeService;
    }

    @GetMapping
    public List<Resume> getAllResumes() {
        return resumeService.getAllResumes();
    }

    @GetMapping("/{id}")
    public Resume getResumeById(@PathVariable String id) {
        return resumeService.getResumeById(id);
    }

    @PostMapping
    public Resume createResume(@RequestBody Resume resume) {
        return resumeService.saveResume(resume);
    }

    @PutMapping("/{id}")
    public Resume updateResume(@PathVariable String id, @RequestBody Resume resume) {
        resume.setId(id);
        return resumeService.saveResume(resume);
    }

    @DeleteMapping("/{id}")
    public void deleteResume(@PathVariable String id) {
        resumeService.deleteResume(id);
    }

}
