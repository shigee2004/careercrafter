package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Profile;

public interface ProfileService {
	Profile createProfile(Profile profile);
    List<Profile> getAllProfiles();
    Profile getProfileById(Long id);
    Profile updateProfile(Long id, Profile profile);
    void deleteProfile(Long id);

}
