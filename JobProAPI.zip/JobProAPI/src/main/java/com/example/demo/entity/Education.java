package com.example.demo.entity;

import jakarta.persistence.Embeddable;

@Embeddable
public class Education {
	private Long id; 
	private String school;
    private String degree;
    private String fromDate;
    private String toDate;

    public Education() {}

    public Education(String school, String degree, String fromDate, String toDate) {
        this.school = school;
        this.degree = degree;
        this.fromDate = fromDate;
        this.toDate = toDate;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getSchool() { return school; }
    public void setSchool(String school) { this.school = school; }

    public String getDegree() { return degree; }
    public void setDegree(String degree) { this.degree = degree; }

    public String getFromDate() { return fromDate; }
    public void setFromDate(String fromDate) { this.fromDate = fromDate; }

    public String getToDate() { return toDate; }
    public void setToDate(String toDate) { this.toDate = toDate; }

}
