package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Resume;
import com.example.demo.repository.ResumeRepository;

@Service
public class ResumeServiceImpl implements ResumeService{
	private final ResumeRepository resumeRepository;

    public ResumeServiceImpl(ResumeRepository resumeRepository) {
        this.resumeRepository = resumeRepository;
    }

    @Override
    public List<Resume> getAllResumes() {
        return resumeRepository.findAll();
    }

    @Override
    public Resume getResumeById(String id) {
        return resumeRepository.findById(id).orElse(null);
    }

    @Override
    public Resume saveResume(Resume resume) {
        return resumeRepository.save(resume);
    }

    @Override
    public void deleteResume(String id) {
        resumeRepository.deleteById(id);
    }

}
